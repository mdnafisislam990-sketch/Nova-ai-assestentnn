package com.zara.ai

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

enum class CallState { IDLE, CONNECTING, LISTENING, THINKING, SPEAKING, ERROR }

/**
 * One live voice call with Gemini Live (WebSocket, bidirectional audio).
 *  mic  -> 16 kHz mono PCM16 -> Gemini
 *  Gemini -> 24 kHz mono PCM16 -> speaker
 * Mic uses VOICE_COMMUNICATION + AEC/NS/AGC (the same audio pipeline WebRTC calls use on Android),
 * so Zara does not hear herself and you can interrupt her (barge-in).
 */
object LiveSession {
    private const val IN_RATE = 16000
    private const val OUT_RATE = 24000
    private const val ENDPOINT =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    private val _state = MutableStateFlow(CallState.IDLE)
    val state: StateFlow<CallState> = _state.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()
    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var scope: CoroutineScope? = null
    private var ws: WebSocket? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var playQueue = Channel<ByteArray>(Channel.UNLIMITED)
    private val effects = mutableListOf<AudioEffect>()
    private var audioManager: AudioManager? = null
    private var oldMode = AudioManager.MODE_NORMAL
    private var oldSpeaker = false

    @Volatile private var ready = false
    @Volatile private var turnDone = true
    @Volatile private var everReady = false
    @Volatile private var reconnecting = false
    @Volatile private var reconnects = 0
    @Volatile private var pipelinesStarted = false
    @Volatile private var resumeHandle: String? = null
    private var appCtx: Context? = null
    val appContext: Context? get() = appCtx
    private val inBuf = StringBuilder()
    private val outBuf = StringBuilder()

    fun toggleMute() { _muted.value = !_muted.value }

    /** Back to a clean IDLE (also clears an old error). */
    fun clear() { if (_state.value == CallState.ERROR || _state.value == CallState.IDLE) { _error.value = null; _state.value = CallState.IDLE } }

    fun start(ctx: Context) {
        if (scope != null) return
        val app = ctx.applicationContext
        appCtx = app
        Memory.load(app)
        val key = Prefs.apiKey(app)
        if (key.isBlank()) { fail("Add your Gemini API key in Settings → Connections"); return }
        _error.value = null
        _muted.value = false
        _level.value = 0f
        _state.value = CallState.CONNECTING
        ready = false
        turnDone = true
        everReady = false
        reconnecting = false
        reconnects = 0
        pipelinesStarted = false
        resumeHandle = null
        synchronized(inBuf) { inBuf.clear() }
        synchronized(outBuf) { outBuf.clear() }
        playQueue = Channel(Channel.UNLIMITED)
        val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = s

        try {
            setupAudio(app)
        } catch (e: Exception) {
            fail("Audio setup failed: ${e.message}")
            return
        }

        openSocket(app)
    }

    private fun openSocket(app: Context) {
        val key = Prefs.apiKey(app)
        val req = Request.Builder().url("$ENDPOINT?key=$key").build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setupJson(app).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (scope == null || webSocket !== ws) return
                val code = response?.code
                if (code == 400 || code == 401 || code == 403) fail("Gemini rejected the API key or model (HTTP $code)")
                else onDrop(app, "Connection lost: ${t.message ?: "network error"}")
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (scope == null || webSocket !== ws) return
                onDrop(app, if (reason.isBlank()) "Call ended (code $code)" else reason)
            }
        })
    }

    /** Connection dropped / session time ended: silently reconnect (with resumption) so the call keeps going. */
    private fun onDrop(app: Context, why: String) {
        val s = scope ?: return
        if (!everReady || reconnects >= 5) { fail(why); return }
        if (reconnecting) return
        reconnecting = true
        reconnects++
        ready = false
        _state.value = CallState.CONNECTING
        val old = ws
        s.launch {
            try { old?.cancel() } catch (_: Exception) {}
            delay(250)
            if (scope != null) openSocket(app)
        }
    }

    fun stop() {
        flushUser(); flushOut()
        scope?.cancel(); scope = null
        ready = false
        try { ws?.close(1000, "bye") } catch (_: Exception) {}
        ws = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        try { track?.stop() } catch (_: Exception) {}
        track?.release(); track = null
        effects.forEach { try { it.release() } catch (_: Exception) {} }
        effects.clear()
        audioManager?.let {
            try { it.isSpeakerphoneOn = oldSpeaker; it.mode = oldMode } catch (_: Exception) {}
        }
        audioManager = null
        playQueue.close()
        _level.value = 0f
        if (_state.value != CallState.ERROR) _state.value = CallState.IDLE
    }

    private fun fail(msg: String) {
        _error.value = msg
        _state.value = CallState.ERROR
        stop()
    }

    private fun setupJson(ctx: Context): JSONObject {
        val setup = JSONObject()
            .put("model", "models/${Prefs.model(ctx)}")
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", Prefs.voice(ctx))))))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Persona.voice(ctx)))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", PhoneControl.declarations())))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
            .put("sessionResumption", JSONObject().also { r -> resumeHandle?.let { r.put("handle", it) } })
            .put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject()
                .put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH")
                .put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
                .put("prefixPaddingMs", 20)
                .put("silenceDurationMs", 320)))
        return JSONObject().put("setup", setup)
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager = am
        oldMode = am.mode
        @Suppress("DEPRECATION") run { oldSpeaker = am.isSpeakerphoneOn }
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION") run { am.isSpeakerphoneOn = Prefs.speaker(ctx) }

        val minIn = AudioRecord.getMinBufferSize(IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, IN_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn * 2, 8192)
        )
        check(rec.state == AudioRecord.STATE_INITIALIZED) { "microphone unavailable" }
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true; effects += it }
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true; effects += it }
        if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(rec.audioSessionId)?.also { it.enabled = true; effects += it }
        record = rec

        val minOut = AudioTrack.getMinBufferSize(OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(OUT_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setBufferSizeInBytes(maxOf(minOut * 2, 24000))
            .build()
    }

    private fun handle(raw: String) {
        val msg = try { JSONObject(raw) } catch (_: Exception) { return }
        if (msg.has("setupComplete")) { onReady(); return }
        msg.optJSONObject("sessionResumptionUpdate")?.let { u ->
            val h = u.optString("newHandle")
            if (u.optBoolean("resumable") && h.isNotEmpty()) resumeHandle = h
        }
        msg.optJSONObject("toolCall")?.let { handleToolCall(it) }
        if (msg.has("goAway")) { appCtx?.let { onDrop(it, "Session time ended. Tap to talk again.") }; return }
        val sc = msg.optJSONObject("serverContent") ?: return
        sc.optJSONObject("inputTranscription")?.optString("text")?.let { if (it.isNotEmpty()) synchronized(inBuf) { inBuf.append(it) } }
        sc.optJSONObject("outputTranscription")?.optString("text")?.let {
            if (it.isNotEmpty()) { flushUser(); synchronized(outBuf) { outBuf.append(it) } }
        }
        if (sc.optBoolean("interrupted")) { flushPlayback(); turnDone = true; _state.value = CallState.LISTENING; flushOut() }
        sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                val pcm = Base64.decode(inline.optString("data"), Base64.DEFAULT)
                if (pcm.isNotEmpty()) {
                    turnDone = false
                    _state.value = CallState.SPEAKING
                    playQueue.trySend(pcm)
                }
            }
        }
        if (sc.optBoolean("turnComplete")) {
            turnDone = true
            if (playQueue.isEmpty && _state.value == CallState.SPEAKING) _state.value = CallState.LISTENING
            flushUser(); flushOut()
        }
    }

    private fun flushUser() {
        val t = synchronized(inBuf) { val x = inBuf.toString().trim(); inBuf.clear(); x }
        if (t.isNotEmpty()) Memory.add("user", t, "voice")
    }

    private fun flushOut() {
        val t = synchronized(outBuf) { val x = outBuf.toString().trim(); outBuf.clear(); x }
        if (t.isNotEmpty()) Memory.add("model", t, "voice")
    }

    private fun onReady() {
        ready = true
        everReady = true
        reconnecting = false
        reconnects = 0
        _state.value = CallState.LISTENING
        if (pipelinesStarted) return
        pipelinesStarted = true
        appCtx?.let { startScreenWatcher(it) }
        val s = scope ?: return
        val rec = record ?: return
        val trk = track ?: return

        // Playback: Gemini -> speaker
        s.launch {
            trk.play()
            for (chunk in playQueue) {
                trk.write(chunk, 0, chunk.size)
                if (_state.value == CallState.SPEAKING) _level.value = rms(chunk) / 9000f
                if (turnDone && playQueue.isEmpty && _state.value == CallState.SPEAKING) _state.value = CallState.LISTENING
            }
        }

        // Capture: mic -> Gemini
        s.launch {
            rec.startRecording()
            val buf = ShortArray(320) // 20 ms: smaller chunks = Gemini hears you sooner
            var lastVoice = 0L
            var hadVoice = false
            while (isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                val level = rmsShorts(buf, n)
                val st = _state.value
                if (st != CallState.SPEAKING) _level.value = (level / 5000f).coerceIn(0f, 1f)
                if (_muted.value || !ready) continue

                val now = System.currentTimeMillis()
                if (level > 900) { lastVoice = now; hadVoice = true }
                if (hadVoice && st == CallState.LISTENING && now - lastVoice > 900) { _state.value = CallState.THINKING; hadVoice = false }

                val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                bb.asShortBuffer().put(buf, 0, n)
                val json = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                    .put("data", Base64.encodeToString(bb.array(), Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=$IN_RATE")))
                ws?.send(json.toString())
            }
        }
    }

    /** Live screen view: ~1 frame/s (faster for a few seconds after an action), only when the screen changed. */
    @Volatile private var boostUntil = 0L
    private var lastFrameHash = 0

    private fun startScreenWatcher(app: Context) {
        val s = scope ?: return
        s.launch {
            while (isActive) {
                val boosted = System.currentTimeMillis() < boostUntil
                delay(if (boosted) 300 else 700)
                if (!ready || !Prefs.watchScreen(app)) continue
                val svc = ZaraAccessibilityService.instance ?: continue
                if (!boosted && svc.activePackage() == app.packageName) continue // Zara's own call screen
                val jpeg = (try { svc.screenshotJpeg() } catch (_: Exception) { null }) ?: continue
                val h = jpeg.contentHashCode()
                if (h == lastFrameHash) continue
                lastFrameHash = h
                sendImage(jpeg)
            }
        }
    }

    private fun handleToolCall(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        val s = scope ?: return
        s.launch {
            _state.value = CallState.THINKING
            val responses = JSONArray()
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                val name = c.optString("name")
                val args = c.optJSONObject("args") ?: JSONObject()
                val out = try {
                    PhoneControl.execute(name, args) { sendImage(it) }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "tool failed")
                }
                val res = out.optString("result", out.optString("error"))
                if (name != "save_memory") {
                    Memory.add("action", if (name == "look_at_screen") "looked at the screen" else "$name $args -> ${res.take(80)}", "voice")
                }
                boostUntil = System.currentTimeMillis() + 4000
                responses.put(JSONObject().put("id", c.optString("id")).put("name", name).put("response", out))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)).toString())
        }
    }

    private fun sendImage(jpeg: ByteArray) {
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("video", JSONObject()
            .put("data", PhoneControl.b64(jpeg)).put("mimeType", "image/jpeg"))).toString())
    }

    private fun flushPlayback() {
        while (playQueue.tryReceive().isSuccess) { /* drop queued audio */ }
        track?.let { try { it.pause(); it.flush(); it.play() } catch (_: Exception) {} }
    }

    private fun rms(b: ByteArray): Float {
        val n = b.size / 2
        if (n == 0) return 0f
        var sum = 0.0
        for (i in 0 until n) {
            val v = ((b[2 * i + 1].toInt() shl 8) or (b[2 * i].toInt() and 0xFF)).toShort().toInt()
            sum += v.toDouble() * v
        }
        return sqrt(sum / n).toFloat()
    }

    private fun rmsShorts(b: ShortArray, n: Int): Float {
        var sum = 0.0
        for (i in 0 until n) sum += b[i].toDouble() * b[i]
        return sqrt(sum / n).toFloat()
    }
}
