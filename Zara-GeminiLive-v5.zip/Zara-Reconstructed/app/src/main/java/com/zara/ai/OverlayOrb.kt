package com.zara.ai

import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

/**
 * Floating Zara orb that stays on top of every app while a call is running (like a call bubble).
 *  - tap        : mute / unmute
 *  - long press : end the call
 *  - drag       : move it, it snaps to the nearest screen edge
 * It hides itself while the Zara app is open (the big call screen already shows the orb).
 * Needs "Display over other apps"; Zara opens that setting once and shows the orb as soon as it is allowed.
 */
object OverlayOrb {
    private var wm: WindowManager? = null
    private var lp: WindowManager.LayoutParams? = null
    private var view: OrbView? = null
    private var scope: CoroutineScope? = null
    private var app: Application? = null
    private var callbacks: Application.ActivityLifecycleCallbacks? = null
    private var visibleActivities = 0
    private var askedPermission = false
    private val main = Handler(Looper.getMainLooper())

    private fun canDraw(ctx: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    fun show(ctx: Context) {
        val a = ctx.applicationContext as? Application ?: return
        main.post {
            if (view != null) return@post
            app = a
            if (canDraw(a)) { attach(a); return@post }
            if (!askedPermission) {
                askedPermission = true
                try {
                    a.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {}
            }
            // wait (max 2 min) until the user allows it, then show the orb without needing a new call
            val s = CoroutineScope(SupervisorJob() + Dispatchers.Main)
            scope = s
            s.launch {
                var waited = 0
                while (isActive && waited < 120_000) {
                    delay(800); waited += 800
                    if (LiveSession.state.value == CallState.IDLE || LiveSession.state.value == CallState.ERROR) continue
                    if (canDraw(a)) { s.cancel(); scope = null; if (view == null) attach(a); return@launch }
                }
            }
        }
    }

    fun hide() {
        main.post {
            scope?.cancel(); scope = null
            callbacks?.let { app?.unregisterActivityLifecycleCallbacks(it) }
            callbacks = null
            view?.let { v ->
                v.stopAnim()
                try { wm?.removeView(v) } catch (_: Exception) {}
            }
            view = null
            lp = null
        }
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun appInForeground(ctx: Context): Boolean {
        val info = ActivityManager.RunningAppProcessInfo()
        ActivityManager.getMyMemoryState(info)
        return info.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
    }

    private fun attach(ctx: Context) {
        val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val size = dp(ctx, 76)
        val dm = ctx.resources.displayMetrics
        val params = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dm.widthPixels - size - dp(ctx, 2)
            y = (dm.heightPixels * 0.35f).toInt()
        }
        lp = params
        val v = OrbView(ctx)
        view = v
        visibleActivities = if (appInForeground(ctx)) 1 else 0
        v.visibility = if (visibleActivities > 0) View.GONE else View.VISIBLE
        attachTouch(v, size)
        try { w.addView(v, params) } catch (_: Exception) { view = null; return }
        v.startAnim()

        val cb = object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) { visibleActivities++; v.visibility = View.GONE }
            override fun onActivityStopped(activity: Activity) {
                visibleActivities = (visibleActivities - 1).coerceAtLeast(0)
                if (visibleActivities == 0) v.visibility = View.VISIBLE
            }
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        }
        callbacks = cb
        (ctx.applicationContext as Application).registerActivityLifecycleCallbacks(cb)

        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        scope = s
        s.launch {
            combine(LiveSession.state, LiveSession.level, LiveSession.muted) { st, lv, mu -> Triple(st, lv, mu) }
                .collect { (st, lv, mu) -> v.update(st, lv, mu) }
        }
    }

    private fun attachTouch(v: OrbView, size: Int) {
        val ctx = v.context
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var downX = 0f; var downY = 0f
        var startX = 0; var startY = 0
        var dragging = false
        var longFired = false
        val longRun = Runnable {
            longFired = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            endCall(ctx.applicationContext)
        }
        v.setOnTouchListener { _, e ->
            val p = lp
            if (p != null) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y
                        dragging = false; longFired = false
                        v.setPressedScale(true)
                        main.postDelayed(longRun, 650)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) { dragging = true; main.removeCallbacks(longRun) }
                        if (dragging) {
                            p.x = startX + dx.toInt()
                            p.y = startY + dy.toInt()
                            try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        main.removeCallbacks(longRun)
                        v.setPressedScale(false)
                        if (dragging) snapToEdge(v, size)
                        else if (!longFired && e.actionMasked == MotionEvent.ACTION_UP) {
                            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                            LiveSession.toggleMute()
                        }
                    }
                }
            }
            true
        }
    }

    private fun snapToEdge(v: View, size: Int) {
        val p = lp ?: return
        val dm = v.resources.displayMetrics
        val margin = dp(v.context, 2)
        val targetX = if (p.x + size / 2 < dm.widthPixels / 2) margin else dm.widthPixels - size - margin
        val targetY = p.y.coerceIn(0, (dm.heightPixels - size).coerceAtLeast(0))
        val fromX = p.x
        val fromY = p.y
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                val f = it.animatedValue as Float
                p.x = (fromX + (targetX - fromX) * f).toInt()
                p.y = (fromY + (targetY - fromY) * f).toInt()
                try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
            }
            start()
        }
    }

    /** Lightweight custom view (no Compose needed inside a service); shaders are cached so drawing allocates nothing per frame. */
    private class OrbView(ctx: Context) : View(ctx) {
        private var state = CallState.LISTENING
        private var targetLevel = 0f
        private var level = 0f
        private var phase = 0f
        private var press = 1f
        private var pressTarget = 1f

        private var c1 = 0; private var c2 = 0; private var c3 = 0
        private var t1 = 0; private var t2 = 0; private var t3 = 0

        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val base = Paint(Paint.ANTI_ALIAS_FLAG)
        private val blobA = Paint(Paint.ANTI_ALIAS_FLAG)
        private val blobB = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * ctx.resources.displayMetrics.density }
        private val clip = Path()
        private var r = 0f
        private var anim: ValueAnimator? = null

        init {
            setLayerType(LAYER_TYPE_HARDWARE, null)
            val (a, b, c) = palette(CallState.LISTENING)
            c1 = a; c2 = b; c3 = c; t1 = a; t2 = b; t3 = c
        }

        private fun palette(s: CallState): Triple<Int, Int, Int> = when (s) {
            CallState.SPEAKING -> Triple(0xFFFF9A3D.toInt(), 0xFF7B3DFF.toInt(), 0xFFFF5FA8.toInt())
            CallState.THINKING -> Triple(0xFF9DB4FF.toInt(), 0xFF4A55B8.toInt(), 0xFFD0D8F5.toInt())
            CallState.ERROR -> Triple(0xFFFF6A6A.toInt(), 0xFF5A1F2E.toInt(), 0xFFB04A5A.toInt())
            CallState.CONNECTING -> Triple(0xFF9DB4FF.toInt(), 0xFF4A55B8.toInt(), 0xFFD0D8F5.toInt())
            else -> Triple(0xFF2EE6D6.toInt(), 0xFF14607E.toInt(), 0xFF6FD6B8.toInt())
        }

        fun update(s: CallState, lv: Float, muted: Boolean) {
            state = s
            targetLevel = lv.coerceIn(0f, 1f)
            val (a, b, c) = if (muted) Triple(0xFF8A8AA3.toInt(), 0xFF2A2A3C.toInt(), 0xFF6A6A80.toInt()) else palette(s)
            t1 = a; t2 = b; t3 = c
            alpha = if (muted) 0.6f else 1f
        }

        fun setPressedScale(down: Boolean) { pressTarget = if (down) 0.9f else 1f }

        fun startAnim() {
            if (anim != null) return
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 5000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { phase = it.animatedValue as Float; if (visibility == VISIBLE) invalidate() }
                start()
            }
        }

        fun stopAnim() { anim?.cancel(); anim = null }

        override fun onDetachedFromWindow() { stopAnim(); super.onDetachedFromWindow() }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            r = minOf(w, h) * 0.30f
            clip.reset()
            clip.addCircle(w / 2f, h / 2f, r, Path.Direction.CW)
            rebuild()
        }

        private fun mix(a: Int, b: Int, f: Float): Int {
            fun ch(x: Int, s: Int) = (x shr s) and 0xFF
            fun m(s: Int) = (ch(a, s) + (ch(b, s) - ch(a, s)) * f).toInt().coerceIn(0, 255)
            return (m(24) shl 24) or (m(16) shl 16) or (m(8) shl 8) or m(0)
        }

        private fun rebuild() {
            if (r <= 0f) return
            val cx = width / 2f
            val cy = height / 2f
            val clear = Color.TRANSPARENT
            glow.shader = RadialGradient(cx, cy, r * 1.65f, intArrayOf((c1 and 0x00FFFFFF) or 0x80000000.toInt(), clear), null, Shader.TileMode.CLAMP)
            base.shader = RadialGradient(cx, cy, r * 1.1f, intArrayOf(c2, 0xFF060A18.toInt()), null, Shader.TileMode.CLAMP)
            val ax = cx + r * 0.38f; val ay = cy - r * 0.28f
            blobA.shader = RadialGradient(ax, ay, r * 0.75f, intArrayOf((c1 and 0x00FFFFFF) or 0xF2000000.toInt(), clear), null, Shader.TileMode.CLAMP)
            val bx = cx - r * 0.42f; val by = cy + r * 0.30f
            blobB.shader = RadialGradient(bx, by, r * 0.7f, intArrayOf((c3 and 0x00FFFFFF) or 0xD9000000.toInt(), clear), null, Shader.TileMode.CLAMP)
            val hx = cx - r * 0.3f; val hy = cy - r * 0.45f
            shine.shader = RadialGradient(hx, hy, r * 0.5f, intArrayOf(0x48FFFFFF, clear), null, Shader.TileMode.CLAMP)
            ring.color = (c1 and 0x00FFFFFF) or 0x8C000000.toInt()
        }

        override fun onDraw(canvas: Canvas) {
            if (r <= 0f) return
            // ease colours / level / press so everything moves smoothly
            if (c1 != t1 || c2 != t2 || c3 != t3) {
                c1 = mix(c1, t1, 0.14f); c2 = mix(c2, t2, 0.14f); c3 = mix(c3, t3, 0.14f)
                if (near(c1, t1) && near(c2, t2) && near(c3, t3)) { c1 = t1; c2 = t2; c3 = t3 }
                rebuild()
            }
            level += (targetLevel - level) * 0.22f
            press += (pressTarget - press) * 0.3f

            val cx = width / 2f
            val cy = height / 2f
            val breathe = 1f + 0.04f * sin(phase * 6.2831855f)
            val s = breathe * (1f + level * 0.16f) * press

            canvas.save()
            canvas.scale(s, s, cx, cy)
            canvas.drawCircle(cx, cy, r * 1.65f, glow)
            canvas.save()
            canvas.clipPath(clip)
            canvas.drawCircle(cx, cy, r, base)
            canvas.save(); canvas.rotate(phase * 360f, cx, cy); canvas.drawCircle(cx + r * 0.38f, cy - r * 0.28f, r * 0.75f, blobA); canvas.restore()
            canvas.save(); canvas.rotate(-phase * 360f * 0.7f, cx, cy); canvas.drawCircle(cx - r * 0.42f, cy + r * 0.30f, r * 0.7f, blobB); canvas.restore()
            canvas.drawCircle(cx - r * 0.3f, cy - r * 0.45f, r * 0.5f, shine)
            canvas.restore()
            canvas.drawCircle(cx, cy, r, ring)
            canvas.restore()
            if (press != pressTarget || level != targetLevel) invalidate()
        }

        private fun near(a: Int, b: Int): Boolean {
            fun d(s: Int) = abs(((a shr s) and 0xFF) - ((b shr s) and 0xFF))
            return d(24) + d(16) + d(8) + d(0) < 8
        }
    }
}
