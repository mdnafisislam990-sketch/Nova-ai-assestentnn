package com.zara.ai

import android.content.Context

/** Settings only. Chat history / memory live in Memory (separate file) so changing the API key never erases them. */
object Prefs {
    const val DEFAULT_MODEL = "gemini-3.1-flash-live-preview"
    const val DEFAULT_VOICE = "Aoede"
    const val DEFAULT_TEXT_MODEL = "gemini-flash-latest"
    const val DEFAULT_IMAGE_MODEL = "gemini-2.5-flash-image"

    val VOICES = listOf("Aoede", "Puck", "Kore", "Charon", "Fenrir", "Leda", "Orus", "Zephyr")
    val LANGS = listOf("Auto", "English", "Bengali", "Hindi", "Banglish")
    val STT = listOf("English" to "en-US", "Bengali" to "bn-BD", "Hindi" to "hi-IN")
    val ACCENTS = listOf(
        "Purple" to 0xFF9C4DFF, "Pink" to 0xFFFF5FB8, "Blue" to 0xFF4D8DFF,
        "Green" to 0xFF2ECC8F, "Orange" to 0xFFFF8A3D
    )

    private fun sp(c: Context) = c.getSharedPreferences("zara", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d)?.trim().orEmpty().ifBlank { d }
    fun put(c: Context, k: String, v: String) { sp(c).edit().putString(k, v.trim()).apply() }
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }

    fun apiKey(c: Context): String = sp(c).getString("gemini_key", "")?.trim().orEmpty()
    fun model(c: Context): String = str(c, "model", DEFAULT_MODEL)
    fun voice(c: Context): String = str(c, "voice", DEFAULT_VOICE)
    fun textModel(c: Context): String = str(c, "text_model", DEFAULT_TEXT_MODEL)
    fun imageModel(c: Context): String = str(c, "image_model", DEFAULT_IMAGE_MODEL)
    fun language(c: Context): String = str(c, "language", "Auto")
    fun sttLang(c: Context): String = str(c, "stt_lang", "en-US")
    fun speaker(c: Context): Boolean = bool(c, "speaker", true)
    fun watchScreen(c: Context): Boolean = bool(c, "watch_screen", true)
    fun confirmSensitive(c: Context): Boolean = bool(c, "confirm_sensitive", true)
    fun accent(c: Context): Long = sp(c).getLong("accent", 0xFF9C4DFF)
    fun setAccent(c: Context, v: Long) { sp(c).edit().putLong("accent", v).apply() }

    fun save(c: Context, key: String, model: String, voice: String) {
        sp(c).edit().putString("gemini_key", key.trim()).putString("model", model.trim()).putString("voice", voice.trim()).apply()
    }
}
