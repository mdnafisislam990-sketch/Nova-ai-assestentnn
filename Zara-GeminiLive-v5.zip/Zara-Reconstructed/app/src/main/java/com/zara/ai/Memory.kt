package com.zara.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** role: "user" | "model" | "action" (phone action Zara performed). src: "chat" | "voice". */
data class Msg(val role: String, val text: String, val src: String, val ts: Long)
class Session(val id: String, var title: String, var updated: Long, val msgs: MutableList<Msg> = mutableListOf())
data class SessionInfo(val id: String, val title: String, val updated: Long, val count: Int)

/**
 * Permanent on-device memory: every chat, voice transcript and phone action, plus saved facts.
 * Stored in filesDir/zara_memory.json. Independent of the API key, so it survives key changes and app restarts.
 */
object Memory {
    private const val MAX_MSGS = 1500
    private const val MAX_SESSIONS = 200
    private val lock = Any()
    private val sessions = mutableListOf<Session>()
    private val facts = mutableListOf<String>()
    private var currentId = ""
    private var file: File? = null
    private var loaded = false
    private val io = Executors.newSingleThreadExecutor()
    private val pending = AtomicBoolean(false)
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    fun load(ctx: Context) {
        var changed = false
        synchronized(lock) {
            if (!loaded) {
                loaded = true
                val f = File(ctx.applicationContext.filesDir, "zara_memory.json")
                file = f
                try { if (f.exists()) parse(JSONObject(f.readText())) } catch (_: Exception) {}
                changed = true
            }
        }
        if (changed) _version.update { it + 1 }
    }

    private fun parse(o: JSONObject) {
        currentId = o.optString("current")
        o.optJSONArray("facts")?.let { for (i in 0 until it.length()) facts.add(it.getString(i)) }
        o.optJSONArray("sessions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val ses = Session(s.getString("id"), s.optString("title", "Chat"), s.optLong("updated"))
                s.optJSONArray("msgs")?.let { m ->
                    for (j in 0 until m.length()) {
                        val x = m.getJSONObject(j)
                        ses.msgs.add(Msg(x.optString("r"), x.optString("t"), x.optString("s"), x.optLong("ts")))
                    }
                }
                sessions.add(ses)
            }
        }
    }

    private fun toJson(): JSONObject {
        val o = JSONObject().put("current", currentId).put("facts", JSONArray(facts))
        val arr = JSONArray()
        sessions.forEach { s ->
            val m = JSONArray()
            s.msgs.forEach { m.put(JSONObject().put("r", it.role).put("t", it.text).put("s", it.src).put("ts", it.ts)) }
            arr.put(JSONObject().put("id", s.id).put("title", s.title).put("updated", s.updated).put("msgs", m))
        }
        return o.put("sessions", arr)
    }

    private fun scheduleSave() {
        if (pending.compareAndSet(false, true)) {
            io.execute {
                try { Thread.sleep(400) } catch (_: Exception) {}
                pending.set(false)
                writeNow()
            }
        }
    }

    private fun writeNow() {
        val f = file ?: return
        val text = synchronized(lock) { toJson().toString() }
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
        } catch (_: Exception) {}
    }

    private fun bump() { _version.update { it + 1 }; scheduleSave() }

    private fun cur(): Session {
        sessions.firstOrNull { it.id == currentId }?.let { return it }
        val s = Session(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis())
        sessions.add(0, s)
        currentId = s.id
        return s
    }

    fun add(role: String, text: String, src: String) {
        if (text.isBlank()) return
        synchronized(lock) {
            val s = cur()
            val now = System.currentTimeMillis()
            s.msgs.add(Msg(role, text.trim(), src, now))
            while (s.msgs.size > MAX_MSGS) s.msgs.removeAt(0)
            s.updated = now
            if (s.title == "New chat" && role == "user") s.title = text.trim().take(40)
            while (sessions.size > MAX_SESSIONS) {
                val old = sessions.filter { it.id != currentId }.minByOrNull { it.updated } ?: break
                sessions.remove(old)
            }
        }
        bump()
    }

    fun messages(): List<Msg> = synchronized(lock) { cur().msgs.toList() }

    fun sessionList(): List<SessionInfo> = synchronized(lock) {
        sessions.filter { it.msgs.isNotEmpty() }.sortedByDescending { it.updated }
            .map { SessionInfo(it.id, it.title, it.updated, it.msgs.size) }
    }

    fun openSession(id: String) { synchronized(lock) { if (sessions.any { it.id == id }) currentId = id }; bump() }

    fun newSession() {
        synchronized(lock) {
            if (cur().msgs.isNotEmpty()) {
                val s = Session(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis())
                sessions.add(0, s)
                currentId = s.id
            }
        }
        bump()
    }

    fun deleteSession(id: String) {
        synchronized(lock) { sessions.removeAll { it.id == id }; if (currentId == id) currentId = "" }
        bump()
    }

    fun clearChats() { synchronized(lock) { sessions.clear(); currentId = "" }; bump() }

    fun factsList(): List<String> = synchronized(lock) { facts.toList() }
    fun counts(): Pair<Int, Int> = synchronized(lock) { facts.size to sessions.count { it.msgs.isNotEmpty() } }

    fun addFact(f: String) {
        val t = f.trim()
        if (t.isEmpty()) return
        synchronized(lock) { if (facts.none { it.equals(t, true) }) { facts.add(t); while (facts.size > 100) facts.removeAt(0) } }
        bump()
    }

    fun removeFact(i: Int) { synchronized(lock) { if (i in facts.indices) facts.removeAt(i) }; bump() }
    fun clearFacts() { synchronized(lock) { facts.clear() }; bump() }

    /** Saved facts + the latest conversation / phone-action history, to inject into the AI's instructions. */
    fun contextBlock(excludeCurrent: Boolean, maxMsgs: Int = 30): String = synchronized(lock) {
        val sb = StringBuilder()
        if (facts.isNotEmpty()) {
            sb.append("THINGS YOU KNOW ABOUT THE USER (saved memory):\n")
            facts.forEach { sb.append("- ").append(it).append('\n') }
        }
        val all = sessions.filter { !(excludeCurrent && it.id == currentId) }
            .flatMap { it.msgs }.sortedBy { it.ts }.takeLast(maxMsgs)
        if (all.isNotEmpty()) {
            sb.append("\nEARLIER CONVERSATIONS AND PHONE ACTIONS (oldest first):\n")
            all.forEach { m ->
                val who = when (m.role) { "user" -> "User"; "model" -> "Zara"; else -> "[phone action]" }
                sb.append(who).append(": ").append(m.text.take(240)).append('\n')
            }
        }
        sb.toString()
    }
}

/** System prompts shared by voice and chat. */
object Persona {
    private const val CREATOR =
        "CREATOR: if anyone asks who made, created or built you, answer (in the user's language) like this: " +
            "'Ami NAFIZ vaiya ar toiri, se amke toiri korse.' and add that the About Telegram channel is @mdnafis568. "
    private const val MEMORY =
        "MEMORY: you permanently remember all earlier conversations and phone actions listed below, even after the app was closed or the API key changed. " +
            "Use them naturally and never say you lost your memory. When the user tells you something worth keeping (name, likes, plans, routines), call save_memory. "

    private fun lang(ctx: Context): String = when (val l = Prefs.language(ctx)) {
        "Auto" -> "Always reply in the same language the user speaks (English, Hindi, Bengali, Hinglish, Banglish...). "
        "Banglish" -> "Always reply in Banglish (Bengali spoken naturally with some English words). "
        else -> "Always reply in $l unless the user clearly switches language. "
    }

    fun voice(ctx: Context): String {
        val confirm = if (Prefs.confirmSensitive(ctx))
            "Ask the user to confirm out loud before anything sensitive or irreversible (sending a message, paying, deleting, calling, changing settings). "
        else "Act directly without asking for confirmation, except for payments. "
        return "You are Zara, a warm, witty and caring personal AI assistant, speaking in a live voice call. " + lang(ctx) +
            "Keep answers short and natural, like a friend on the phone, and respond fast. Never read out markdown or lists. " + CREATOR + MEMORY +
            "SCREEN: while phone control is on you continuously SEE the user's phone screen as live video, so answer questions about it immediately without calling look_at_screen; use look_at_screen only when you need exact tap coordinates. " +
            "SPEED: start speaking at once with a very short reply (a few words, e.g. 'ji, kortesi'), then act; never wait silently. " +
            "DIRECT ACTIONS (use these FIRST, never call look_at_screen for them): call_contact for 'call X', send_sms for a text message, " +
            "send_whatsapp for a WhatsApp message, play_youtube for 'search/play this song on YouTube'. Pass the name exactly as the user said it. " +
            "If the user did not say the message text, ask for it first. After the tool returns ok, tell the user briefly what you did. " +
            "PHONE CONTROL: for everything else you can control the user's phone with your tools (look_at_screen, tap, long_press, swipe, scroll, click_text, type_text, press_key, open_app). " +
            "When asked to do something on the phone, call look_at_screen first, then act step by step using the pixel coordinates from the element list, " +
            "and check the result with look_at_screen again. Prefer click_text and open_app when possible. " + confirm +
            "Never type or read out passwords or OTP codes. If a tool says phone control is OFF, tell the user to enable it in Zara Settings > Phone control.\n\n" +
            Memory.contextBlock(excludeCurrent = false)
    }

    fun chat(ctx: Context): String =
        "You are Zara, a warm, witty and caring personal AI assistant in a text chat. " + lang(ctx) +
            "Be helpful, clear and reasonably concise. Use plain text (no markdown tables or heavy formatting). " + CREATOR +
            "MEMORY: you remember earlier conversations and what you did on the user's phone, listed below. Use them naturally.\n\n" +
            Memory.contextBlock(excludeCurrent = true)
}
